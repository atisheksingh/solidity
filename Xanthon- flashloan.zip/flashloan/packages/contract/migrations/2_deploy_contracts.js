require("dotenv").config();

const ZLLibrary = artifacts.require("ZLLibrary");
const ZLFlashLoan = artifacts.require("ZLFlashLoan");
module.exports = function (deployer, network, accounts) {
  deployer.deploy(ZLLibrary);
  deployer.link(ZLLibrary, ZLFlashLoan);
  deployer.deploy(
    ZLFlashLoan,
    process.env.AAVE_POOL_ADDRESSES_PROVIDER,
    {
      overwrite: false,
      from: accounts[0],
    }
  );
};
