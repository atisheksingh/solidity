const ZLFlashLoan = require('./output/ZLFlashLoan.json');

module.exports = { ZLFlashLoan };