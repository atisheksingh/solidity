const ZLFlashLoan = artifacts.require("ZLFlashLoan");

const ADDR = {
	routers: {
		uniV3: '0xE592427A0AEce92De3Edee1F18E0157C05861564',
		uniV2: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
		sushi: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506',
	},
	tokens: {
		wbtc: '0x37022f97333df61a61595b7cf43b63205290f8ee',
		weth: '0x98a5f1520f7f7fb1e83fe3398f9abd151f8c65ed',
		usdt: '0xa0704bfa9e17cf4a1d74a60db7bcda1b5d00d3e6',
		dai: '0x2ec4c6fcdbf5f9beeceb1b51848fc2db1f3a26af',
		aave: '0x953af320e2bD3041c4e56BB3a30E7f613a1f3C1A',
	}
};

contract('ZLFlashLoan', accounts => {
	let scInst;

	beforeEach(async () => {
		scInst = await ZLFlashLoan.deployed();
	});

	/* it('Check who is owner', async () => {
		const owner = await scInst.owner();
		assert.equal(owner, accounts[0], 'Wrong owner!');
	}); */

	it('Flashloan<->Uniswap<->Sushiswap', async () => {
		const result = await scInst.doTask(
			ADDR.tokens.wbtc,
			web3.utils.toWei('1'),
			[ADDR.routers.uniV2, ADDR.routers.sushi, ADDR.routers.uniV3],
			["0", "0", "1"],
			[ADDR.tokens.dai, ADDR.tokens.usdt, ADDR.tokens.wbtc],
			{
				from: accounts[0],
				gasLimit: 30000000,
			}
		);

		assert.equal(result, accounts[0], 'Wrong owner!');
	});

	/*
	it('Test Withdraw', async () => {
	});
	*/
});
